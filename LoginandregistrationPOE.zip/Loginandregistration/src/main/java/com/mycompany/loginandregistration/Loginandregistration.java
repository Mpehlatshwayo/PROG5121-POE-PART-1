/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregistration;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




/**
 *
 * @author Mpendulo12
 */

public class Loginandregistration {
   
 

    // ---------- Configuration 
    // ---------- Configuration ----------
// This sets the maximum size (capacity) for all arrays in the program.
// In other words, we can store up to 500 items (messages, users, etc.)
private static final int MAX = 500; 



    // ---------- Message storage (arrays) ----------
// Stores the actual text of each sent message,Stores the phone numbers of recipients
// Stores unique IDs for each sent message,Stores a "hash" (short code) for each message
//Stores the usernames of senders ,Keeps track of how many messages have been sent
    static String[] sentMessages = new String[MAX];
    static String[] sentRecipients = new String[MAX];
    static String[] sentMessageID = new String[MAX];
    static String[] sentMessageHash = new String[MAX];
    static String[] sentSenders = new String[MAX];
    static int sentCount = 0;

    
    static String[] disregardedMessages = new String[MAX];// Stores messages that were not accepted
    static int disregardedCount = 0;//counts amount odf messages diregarded
    
// Arrays to keep track of stored (saved) messages
    static String[] storedMessages = new String[MAX];// Stores the text of saved messages
    static String[] storedMessageID = new String[MAX];// Stores IDs for saved messages
    static String[] storedMessageHash = new String[MAX];//Stores hash codes for saved messages
    static String[] storedRecipients = new String[MAX]; //Stores recipients of saved messages
    static int storedCount = 0; //count number of messages stored

    // Array to keep trak of registered users
    static String[] usernames = new String[MAX];//sores usernames
    static String[] passwords = new String[MAX];//stores password
    static String[] names = new String[MAX];//stores name
    static int userCount = 0;//counts number of regstereed users

    // general counters and flags
    static int messageCount = 0; // total stored/sent count
    static boolean isLoggedIn = false;//checks if user is logged in

    // ---------- Validation & util methods ----------

    // Generate a 10-digit ID randomly
    //andom number up to 10 digits
    public static String generateMessageID() {
        long id = (long) (Math.random() * 1_000_000_0000L);
        return String.format("%010d", id);
    }

    // Check SA number format +27 and total 12 chars + sign
    public static boolean checkRecipientCell(String cell) {
        return cell != null && cell.startsWith("+27") && cell.length() == 12;
    }

   
    // Check if a message is valid
// Must not be empty and must be 250 characters or less
    public static boolean isValidMessage(String msg) {
        return msg != null && !msg.trim().isEmpty() && msg.length() <= 250;
    }

    // Create simple hash
    // Create a simple "hash" for a message
// This combines parts of the message ID and words from the message
    public static String createMessageHash(String messageID, String message) {
        
        if (message == null || message.trim().isEmpty()) {
            // If the message is empty, mark it as EMPTY


            return (messageID + ":EMPTY").toUpperCase();
        }
         // Split the message into words
        String[] words = message.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        String prefix = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        char firstChar = messageID.length() > 0 ? messageID.charAt(0) : '0';
         // Build the hash string and convert to uppercase


        return (prefix + ":" + firstChar + ":" + firstWord + lastWord).toUpperCase();
    }
    
// Check if a password is valid
    public static boolean isValidPassword(String password) {
        // If the password is empty (null), it is not valid
        if (password == null) return false;
        
         // Check if the password has at least one capital letter (A–Z
        boolean hasCapital = password.matches(".*[A-Z].*");
        
        // Check if the password has at least one number (0–9)
        boolean hasNumber = password.matches(".*[0-9].*");
        // Check if the password has at least one special character (!, @, #, $, etc.)
        boolean hasSpecial = password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        // The password is valid
    // 1 It has 8 or more characters
    // 2 It contains a capital letter
    // 3  It contains a number
    // 4 It contains a special character

        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // Escape basic JSON characters
    // This method makes sure special characters are safe to use in JSON forma
    private static String escapeForJson(String s) {
        if (s == null) return "";
            // Replace backslashes (\) with double backslashes (\\)
    // Replace double quotes (") with escaped quotes (\")
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
// Undo the escaping of JSON characters
// This method converts the safe JSON string back to normal text
    private static String unescapeFromJson(String s) {
        
        if (s == null) return "";
        return s.replace("\\\"", "\"").replace("\\\\", "\\");
    }

    // ---------- File storage ----------

    // Append one JSON-like object per message (simple format)
    
    public static void storeMessageToFile(String messageID, String hash, String recipient, String message) {
       // Build a JSON string that contains message details
        String json = "{\n" +
                "  \"messageID\": \"" + escapeForJson(messageID) + "\",\n" +
                "  \"hash\": \"" + escapeForJson(hash) + "\",\n" +
                "  \"recipient\": \"" + escapeForJson(recipient) + "\",\n" +
                "  \"message\": \"" + escapeForJson(message) + "\"\n" +
                "}";
        // Try to save the JSON string into a file called "storedMessagess.json"

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("storedMessagess.json", true))) {
            bw.write(json); // Write the JSON data into the file
            bw.newLine();// Add a new line after each message

        } catch (IOException e) {
            // Show an error message if something goes wrong while saving
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage());
        }
    }

    // Load previously stored messages into arrays (tolerant simple parser)
    public static void loadStoredMessagesFromFile() {
        File f = new File("storedMessagess.json");
        if (!f.exists()) return;
   // Patterns to find specific parts of the JSON (ID, hash, recipient, message)

        Pattern idPattern = Pattern.compile("\"messageID\"\\s*:\\s*\"([^\"]+)\"");
        Pattern hashPattern = Pattern.compile("\"hash\"\\s*:\\s*\"([^\"]+)\"");
        Pattern recipientPattern = Pattern.compile("\"recipient\"\\s*:\\s*\"([^\"]+)\"");
        Pattern messagePattern = Pattern.compile("\"message\"\\s*:\\s*\"([^\"]+)\"");

        try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Collect lines until we reach the end of a JSON object (marked by '}')
               // an object may span multiple lines, so collect until '}'
                StringBuilder json = new StringBuilder(line);
                if (!line.trim().endsWith("}")) {
                    String extra;
                    while ((extra = reader.readLine()) != null) {
                        json.append(extra);
                        if (extra.trim().endsWith("}")) break;
                    }
                }
                String jsonLine = json.toString();
            // Match each part of the JSON using the patterns
                Matcher mId = idPattern.matcher(jsonLine);
                Matcher mHash = hashPattern.matcher(jsonLine);
                Matcher mRecipient = recipientPattern.matcher(jsonLine);
                Matcher mMessage = messagePattern.matcher(jsonLine);
           
     // Extract values (or use empty string if not found)
                String id = mId.find() ? unescapeFromJson(mId.group(1)) : "";
                String hash = mHash.find() ? unescapeFromJson(mHash.group(1)) : "";
                String recipient = mRecipient.find() ? unescapeFromJson(mRecipient.group(1)) : "";
                String message = mMessage.find() ? unescapeFromJson(mMessage.group(1)) : jsonLine;

// Store the values into arrays if there is space

// Store the values into arrays if there is space

                if (storedCount < MAX) {
                    storedMessageID[storedCount] = id;
                    storedMessageHash[storedCount] = hash;
                    storedRecipients[storedCount] = recipient;
                    storedMessages[storedCount] = message;
                    storedCount++;
                } else break;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading stored messages: " + e.getMessage());
        }
    }

    // ---------- Send flow (now uses arrays) ----------
    private static void sendMessageFlow(String currentSender) {
        String recipient = JOptionPane.showInputDialog("Enter recipient cell number (+27...)");
        if (recipient == null) return;
// Validate the cell number format
        if (!checkRecipientCell(recipient)) {
            JOptionPane.showMessageDialog(null,
                    "Cell phone number incorrectly formatted.\nPlease correct and try again.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Cell phone number successfully captured.");
        }
// Ask the user for the message text


        String message = JOptionPane.showInputDialog("Enter your message (max 250 characters)");
        if (message == null) return;

        if (!isValidMessage(message)) {
            int excess = Math.max(0, message.length() - 250);
            JOptionPane.showMessageDialog(null,
                    "Message exceeds 250 characters by " + excess + ". Please reduce size.");
            return;
        } else {
            JOptionPane.showMessageDialog(null, "Message is ready to send.");
        }
 // Generate a unique ID and hash for the message

        String messageID = generateMessageID();
        String hash = createMessageHash(messageID, message);

     // Ask the user what action they want to take
   
        String action = JOptionPane.showInputDialog("""
                Choose:
                1) Send
                2) Disregard
                3) Store
                4) View stored messages
                """);
        if (action == null) return;
//Build a JSON string that contains message details
        String details = "Message Details:\n" +
                "Message ID: " + messageID + "\n" +
                "Message Hash: " + hash + "\n" +
                "Recipient: " + recipient + "\n" +
                "Message: " + message;
//Handle the user's choice
        switch (action) {
            case "1" -> {
                if (sentCount < MAX) {
                    sentSenders[sentCount] = currentSender;
                    sentRecipients[sentCount] = recipient;
                    sentMessages[sentCount] = message;
                    sentMessageID[sentCount] = messageID;
                    sentMessageHash[sentCount] = hash;
                    sentCount++;
                    messageCount++;
                    JOptionPane.showMessageDialog(null, "Message successfully sent.\n\n" + details);
                } else {
                    JOptionPane.showMessageDialog(null, "Sent messages array is full.");
                }
            }
            //diregrads user choice
            case "2" -> {
                if (disregardedCount < MAX) {
                    disregardedMessages[disregardedCount++] = message;
                    JOptionPane.showMessageDialog(null, "Message discarded.\n\n" + details);
                } else {
                    JOptionPane.showMessageDialog(null, "Disregarded messages array is full.");
                }
            }
            //stores user choice
            case "3" -> {
                if (storedCount < MAX) {
                    storedMessages[storedCount] = message;
                    storedMessageID[storedCount] = messageID;
                    storedMessageHash[storedCount] = hash;
                    storedRecipients[storedCount] = recipient;
                    storedCount++;
                    storeMessageToFile(messageID, hash, recipient, message);
                    messageCount++;
                    JOptionPane.showMessageDialog(null, "Message successfully stored.");
                } else {
                    JOptionPane.showMessageDialog(null, "Stored messages array is full.");
                }
            }
            //View stored messages
            case "4" -> {
                if (storedCount == 0) {
                    JOptionPane.showMessageDialog(null, "No stored messages.");
                } else {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < storedCount; i++) {
                        sb.append("ID: ").append(storedMessageID[i]).append("\n");
                        sb.append("Hash: ").append(storedMessageHash[i]).append("\n");
                        sb.append("Recipient: ").append(storedRecipients[i]).append("\n");
                        sb.append("Message: ").append(storedMessages[i]).append("\n\n");
                    }
                    JOptionPane.showMessageDialog(null, sb.toString());
                }
            }
            default -> JOptionPane.showMessageDialog(null, "Invalid option.");
        }
    }

    // ---------- Option A features implementation ----------

    // a) Show total messages sent (sentCount)
    // This method just shows how many messages the user has already sent.
    // I kept it simple because it's only reading a counter variable
    private static void showTotalMessages() {
        JOptionPane.showMessageDialog(null, "Total messages sent: " + sentCount);
    }

    // b) Show longest message
     // Here I'm checking which message has the most characters.
    // I'm looping through all the sent messages and saving the one with the biggest length
    private static void showLongestMessage() {
        if (sentCount == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages yet.");
            return;
        }
     // assuming the first message is the longest until proven otherwise   
        int longestIndex = 0;
       int longestLen = sentMessages[0] != null ? sentMessages[0].length() : 0;
       // checking the rest of the messages
        for (int i = 1; i < sentCount; i++) {
            if (sentMessages[i] != null && sentMessages[i].length() > longestLen) {
                longestLen = sentMessages[i].length();
                longestIndex = i;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest message (len " + longestLen + "):\n" + sentMessages[longestIndex]);
    }

    // c) Show shortest message
    // I'm checking for the smallest length.
    private static void showShortestMessage() {
        if (sentCount == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages yet.");
            return;
        }
        int shortestIndex = -1;
        int shortestLen = Integer.MAX_VALUE;// starting high so any real value is smaller
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i] != null) {
                // updating when a smaller message is found
                int len = sentMessages[i].length();
                if (len < shortestLen) {
                    shortestLen = len;
                    shortestIndex = i;
                }
            }
        }
        if (shortestIndex >= 0) {
            JOptionPane.showMessageDialog(null, "Shortest message (len " + shortestLen + "):\n" + sentMessages[shortestIndex]);
        }
    }

    // d) Search for a message by ID (shows recipient & message)
     // Here I search through BOTH sent and stored messages.
    // Once I find the ID, I show who the message was for and what was written.
    private static void searchByID() {
        String id = JOptionPane.showInputDialog("Enter message ID to search:");
        if (id == null) return;
         //search if message is first
        for (int i = 0; i < sentCount; i++) {
            if (id.equals(sentMessageID[i])) {
                JOptionPane.showMessageDialog(null, "Found (sent):\nRecipient: " + sentRecipients[i] + "\nMessage: " + sentMessages[i]);
                return;
            }
        }
        //searching in stored messages if not found in sent
        for (int i = 0; i < storedCount; i++) {
            if (id.equals(storedMessageID[i])) {
                JOptionPane.showMessageDialog(null, "Found (stored):\nRecipient: " + storedRecipients[i] + "\nMessage: " + storedMessages[i]);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // e) Count how many messages contain a specific word
     //search if message is first
    private static void countMessagesWithWord() {
        String word = JOptionPane.showInputDialog("Enter word to search for (case-insensitive):");
        if (word == null) return;
        int count = 0;
        String lower = word.toLowerCase();
         //search if message is first
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i] != null && sentMessages[i].toLowerCase().contains(lower)) count++;
        }
        JOptionPane.showMessageDialog(null, "Messages containing \"" + word + "\": " + count);
    }

    // f) Display all messages with their IDs
     //search if message is first
    private static void displayAllMessagesWithIDs() {
        if (sentCount == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentCount; i++) {
             //formatting for each message so the messages are easy to read
            sb.append("ID: ").append(sentMessageID[i]).append("\n");
            sb.append("Sender: ").append(sentSenders[i]).append("\n");
            sb.append("Recipient: ").append(sentRecipients[i]).append("\n");
            sb.append("Message: ").append(sentMessages[i]).append("\n");
            sb.append("------------------------------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // g) Delete a message by ID (sent or stored)
     //search if message is first
    private static void deleteMessageByID() {
        String id = JOptionPane.showInputDialog("Enter message ID to delete:");
        if (id == null) return;
        // try sent
        for (int i = 0; i < sentCount; i++) {
            if (id.equals(sentMessageID[i])) {
                // shift left
                for (int j = i; j < sentCount - 1; j++) {
                    sentMessageID[j] = sentMessageID[j + 1];
                    sentMessageHash[j] = sentMessageHash[j + 1];
                    sentMessages[j] = sentMessages[j + 1];
                    sentRecipients[j] = sentRecipients[j + 1];
                    sentSenders[j] = sentSenders[j + 1];
                }
                sentCount--; //reduce count
                JOptionPane.showMessageDialog(null, "Message deleted from sent messages.");
                return;
            }
        }
        // try stored
        for (int i = 0; i < storedCount; i++) {
            if (id.equals(storedMessageID[i])) {
                //checks stored message
                for (int j = i; j < storedCount - 1; j++) {
                    storedMessageID[j] = storedMessageID[j + 1];
                    storedMessageHash[j] = storedMessageHash[j + 1];
                    storedMessages[j] = storedMessages[j + 1];
                    storedRecipients[j] = storedRecipients[j + 1];
                }
                storedCount--;
                JOptionPane.showMessageDialog(null, "Message deleted from stored messages.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // h) Show statistics (average length)
      //here i am calculating the avg lengsth of messages , the shortest and longest message
    private static void showStatistics() {
        if (sentCount == 0) {
            JOptionPane.showMessageDialog(null, "No sent messages yet.");
            return;
        }
        int totalLen = 0;
        int min = Integer.MAX_VALUE;
        int max = 0;
        //looping through all the messages to calculate the statistics
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i] == null) continue;
            int len = sentMessages[i].length();
            totalLen += len;
            if (len < min) min = len;//updating shortest
            if (len > max) max = len;//updating longest
        }
        double average = (double) totalLen / sentCount;
        String out = "Sent messages: " + sentCount + "\n" +
                "Average length: " + String.format("%.2f", average) + "\n" +
                "Shortest length: " + min + "\n" +
                "Longest length: " + max;
        JOptionPane.showMessageDialog(null, out);
    }

    // ---------- GUI main ----------
    public static void main(String[] args) {
        // Load stored messages on startup
        loadStoredMessagesFromFile();

        // Build frame and components (similar to your original look)
        JFrame frame = new JFrame("Login & Registration");
        frame.setSize(600, 480);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 250, 205)); // pastel yellow
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JLabel phoneLabel = new JLabel("Phone (+27...):");
        JLabel nameLabel = new JLabel("Name:");
        JLabel messageLabel = new JLabel("");
        JLabel welcomeLabel = new JLabel("");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.PINK);

        JTextField usernameField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        JTextField phoneField = new JTextField(15);
        JTextField nameField = new JTextField(15);

        JButton registerButton = new JButton("Register");
        JButton loginButton = new JButton("Login");

        Color pastelBlue = new Color(204, 229, 255);
        Color pastelPink = new Color(255, 204, 229);

        usernameField.setBackground(pastelBlue);
        passwordField.setBackground(pastelBlue);
        phoneField.setBackground(pastelBlue);
        nameField.setBackground(pastelBlue);

        registerButton.setBackground(pastelPink);
        loginButton.setBackground(pastelPink);

        // Layout placement
        gbc.gridx = 0; gbc.gridy = 0; panel.add(userLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; panel.add(usernameField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(passLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; panel.add(passwordField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panel.add(phoneLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 2; panel.add(phoneField, gbc);
        gbc.gridx = 0; gbc.gridy = 3; panel.add(nameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 3; panel.add(nameField, gbc);
        gbc.gridx = 0; gbc.gridy = 4; panel.add(registerButton, gbc);
        gbc.gridx = 1; gbc.gridy = 4; panel.add(loginButton, gbc);
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2; panel.add(messageLabel, gbc);
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2; panel.add(welcomeLabel, gbc);

        frame.add(panel);
        frame.setVisible(true);
        frame.toFront();
        frame.requestFocus();

        // ---------- Register action ----------
        // When the user clicks the register button, I'm collecting the input
        // and basically checking if everything is formatted correctly before saving it
        registerButton.addActionListener((ActionEvent e) -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String phone = phoneField.getText();
            String fullName = nameField.getText();
// Checking username requirements:
            // It must contain an underscore and not be longer than 5 characters.
            if (username == null || username.isEmpty() || (!username.contains("_") || username.length() > 5)) {
                messageLabel.setText("Username incorrectly formatted.");
                // Now checking if password meets the rules
            } else if (!isValidPassword(password)) {
                messageLabel.setText("Password does not meet requirements.");
                 // Phone number must start with +27 and follow the SA mobile number pattern
            } else if (!phone.matches("\\+27[6-8][0-9]{8}")) {
                messageLabel.setText("Cellphone number incorrectly formatted.");
            } else {
                if (userCount < MAX) {
                    usernames[userCount] = username;
                    passwords[userCount] = password;
                    names[userCount] = fullName;
                    userCount++;
             // Letting the user know that the registration went fine        
                    messageLabel.setText("✅ Registration complete!");
                    // If the array is full, I warn the user
                } else {
                    messageLabel.setText("User storage is full.");
                }
            }
        });

        // ---------- Login action ----------
         // This part runs when the user clicks "Login".
        // I'm comparing what they typed with the users stored during registration.
        loginButton.addActionListener((ActionEvent e) -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            int foundIndex = -1;
             // Looping through all registered users and checking for a match
            for (int i = 0; i < userCount; i++) {
                if (usernames[i].equals(username) && passwords[i].equals(password)) {
                    foundIndex = i;
                    break;//If foundIndex stays -1 then the login failed
                }
            }

            if (foundIndex == -1) {
                messageLabel.setText("Username or password incorrect.");
                return;
            }

            // successful login
            messageLabel.setText("Welcome " + username + ", " + names[foundIndex]);
            welcomeLabel.setText("WELCOME TO QUICKCHAT");
            isLoggedIn = true;

            // Ask how many messages they want to send (keep this behavior)
            String input = JOptionPane.showInputDialog(frame, "How many messages do you want to send?");
            if (input == null) return;
            int totalMessages;
            try {
                totalMessages = Integer.parseInt(input);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid number. Defaulting to 1.");
                totalMessages = 1;
            }

            int sentMessages = 0;
            while (true) {
                String menu = """
                        Choose an option:
                        1. Send Message
                        2. Show Recently Sent Messages (Coming Soon)
                        3. More Tools (Option A)
                        4. Quit
                        """;
                String choice = JOptionPane.showInputDialog(frame, menu);
                if (choice == null) break;

                switch (choice) {
                    case "1" -> {
                        if (sentMessages < totalMessages) {
                            sendMessageFlow(username);
                            sentMessages++;
                        } else {
                            JOptionPane.showMessageDialog(frame, "You've reached your message limit.");
                        }
                    }
                    case "2" -> JOptionPane.showMessageDialog(frame, "Coming Soon.");
                    case "3" -> {
                        // This is the advanced menu I added for Option a
                        String advMenu = """
                                More Tools :
                                a) Show total messages sent
                                b) Show longest message
                                c) Show shortest message
                                d) Search message by ID
                                e) Count messages containing a word
                                f) Display all messages with IDs
                                g) Delete message by ID
                                h) Show statistics (average length)
                                i) Back
                                """;
                        String advChoice = JOptionPane.showInputDialog(frame, advMenu);
                        if (advChoice == null) break;
                        switch (advChoice.toLowerCase()) {
                            case "a" -> showTotalMessages();
                            case "b" -> showLongestMessage();
                            case "c" -> showShortestMessage();
                            case "d" -> searchByID();
                            case "e" -> countMessagesWithWord();
                            case "f" -> displayAllMessagesWithIDs();
                            case "g" -> deleteMessageByID();
                            case "h" -> showStatistics();
                            case "i" -> { /*  goes back to the main menu*/ }
                            default -> JOptionPane.showMessageDialog(frame, "Invalid option.");
                        }
                    }
                    case "4" -> {
                        //user wants to exit the menu
                        JOptionPane.showMessageDialog(frame, "Goodbye!");
                        return;
                    }
                    default -> JOptionPane.showMessageDialog(frame, "Invalid option.");
                }
            }
        });
    }

  

}
      
    

